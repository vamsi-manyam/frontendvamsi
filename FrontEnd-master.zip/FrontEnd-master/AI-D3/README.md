$ git clone git@github.com:aidatabases/FrontEnd.git
$ cd AI-D3
$ npm update
$ npm install
$ npm start
```

Start the server by running `npm start` command

The UI expects elastic search to be running on 9200 port.
